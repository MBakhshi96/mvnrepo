yajsw-stable-11.11

    * Bug: on application restart: stream of prev process is open although new process started.
    * Bug: 11.10 zip file incorrect version
    * Bug: Linux: quotes and spaces in command line paths
    * Bug: Bug: WrappedRuntimeProcess: mkdirs if folder for pid file does not exist
    * Bug: Minor changes in RuntimeJavaMain
    * Bug: missing .processTerminated invocation in WrappedRuntimeProcess
    * Bug: NPE when restartGC is set but no no output format is set.
    * Change: logging in gobbler
    * New: new: Property wrapper.ntservice.process_priority
